function loadRecord(){
    let campoRecord = document.getElementById("record");
    campoRecord.textContent = 0;
    if( localStorage.getItem("record") != null &&
        localStorage.getItem("record") != undefined ){

        let ranking = JSON.parse(localStorage.getItem("record"))
        campoRecord.textContent = ranking[0].record
    }
}

function novoRecord(){
    let pontuacaoAtual = document.getElementById("pontuacao-atual").value
    let nome = prompt("Qual o Seu Nome?");
    let agora = Date.now();

    let novoRecord = {
        timestamp : agora,
        nomeDoJogador: nome,
        record: pontuacaoAtual
    }
    
    // ranking = [
    //    {   },
    //    {   },
    //    {   },
    //]
    let ranking = JSON.parse(localStorage.getItem("record"))
    ranking.unshift(novoRecord)

    localStorage.setItem("record",JSON.stringify(ranking))
    loadRecord()
}


var ranking = [
,
    {
        timestamp : "13/01/2020",
        nomeDoJogador: "Atila",
        record: 400
    },
    {
        timestamp : "10/01/2020",
        nomeDoJogador: "Milton",
        record: 350
    },
]


function iniciaJogo(){
    let card1 = document.getElementById("card-1");
    card1.innerHTML = 
    `
    Questão 1 <br>
    <img id="img-1" src="${deck[2].imgSrc}" alt="FIG 1"> <br>
    <input type="radio" name="resp-1" id="alt11"><label>${deck[0].alternativa1}</label><br>
    <input type="radio" name="resp-1" id="alt12"><label>${deck[0].alternativa2}</label><br>
    <input type="radio" name="resp-1" id="alt13"><label>${deck[0].alternativa3}</label><br>
    `
    let card2 = document.getElementById("card-2");
    card2.innerHTML = 
    `
    Questão 2 <br>
    <img id="img-2" src="${deck[2].imgSrc}" alt="Fig 2"> <br>
    <input type="radio" name="resp-2" id="alt21"><label>${deck[1].alternativa1}</label><br>
    <input type="radio" name="resp-2" id="alt22"><label>${deck[1].alternativa2}</label><br>
    <input type="radio" name="resp-2" id="alt23"><label>${deck[1].alternativa3}</label><br>
    `
    let card3 = document.getElementById("card-3");
    card3.innerHTML = 
    `
    Questão 3 <br>
    <img id="img-3" src="${deck[2].imgSrc}" alt="Fig 3"> <br>
    <input type="radio" name="resp-3" id="alt31"><label>${deck[2].alternativa1}</label><br>
    <input type="radio" name="resp-3" id="alt32"><label>${deck[2].alternativa2}</label><br>
    <input type="radio" name="resp-3" id="alt33"><label>${deck[2].alternativa3}</label><br>
    `
    
    loadRecord()
}
