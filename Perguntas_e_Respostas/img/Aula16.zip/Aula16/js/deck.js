var deck = [
    {
        id: 1,
        imgSrc : "./img/card1.jpg",
        alternativa1 : "Card1 - Alt 1",
        alternativa2 : "Card1 - Alt 2",
        alternativa3 : "Card1 - Alt 3",
        correta : 2,
        pontos: 40
    },
    {
        id: 2,
        imgSrc : "./img/card2.jpg",
        alternativa1 : "Card2 - Alt 1",
        alternativa2 : "Card2 - Alt 2",
        alternativa3 : "Card2 - Alt 3",
        pontos: 40
    },
    {
        id: 3,
        imgSrc : "./img/card3.jpg",
        alternativa1 : "Card3 - Alt 1",
        alternativa2 : "Card3 - Alt 2",
        alternativa3 : "Card3 - Alt 3",
        pontos : 10
    },
]